# coarse106
python train.py configs/cifar10.py

