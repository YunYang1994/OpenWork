from mmengine import Registry

MODELS = Registry('models')