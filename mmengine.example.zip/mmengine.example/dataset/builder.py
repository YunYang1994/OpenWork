from mmengine import Registry

DATASETS = Registry('dataset')

